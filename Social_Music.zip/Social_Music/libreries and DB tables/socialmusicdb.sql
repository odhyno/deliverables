-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Gen 31, 2021 alle 20:51
-- Versione del server: 10.4.17-MariaDB
-- Versione PHP: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `socialmusicdb`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `messaggi`
--

CREATE TABLE `messaggi` (
  `id` int(5) NOT NULL,
  `mittente` varchar(45) NOT NULL,
  `ricevente` varchar(45) NOT NULL,
  `testo` varchar(999) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struttura della tabella `notifica`
--

CREATE TABLE `notifica` (
  `username` varchar(45) NOT NULL,
  `valoreAttuale` int(5) NOT NULL,
  `valoreConosciuto` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `notifica`
--

INSERT INTO `notifica` (`username`, `valoreAttuale`, `valoreConosciuto`) VALUES
('admin', 0, 0),
('casa', 0, 0),
('fase', 0, 0),
('gino', 2, 2),
('palo', 0, 0),
('trilli', 0, 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `post`
--

CREATE TABLE `post` (
  `idPost` int(11) NOT NULL,
  `titolo` varchar(45) NOT NULL,
  `autore` varchar(18) NOT NULL,
  `descrizione` varchar(999) NOT NULL,
  `nomeSample` varchar(45) DEFAULT NULL,
  `argomento` varchar(18) DEFAULT NULL,
  `risolto` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `post`
--

INSERT INTO `post` (`idPost`, `titolo`, `autore`, `descrizione`, `nomeSample`, `argomento`, `risolto`) VALUES
(2, 'adminpost', 'admin', 'adminpost', '07 Drones.m4a', 'null', 'null'),
(3, 'palopost', 'palo', 'ploposto', '06 Runaway.m4a', 'null', 'null'),
(4, 'admin secondo post esc', 'admin', 'adondsfnsoefnes', '8-05 The Great Gig In the Sky.m4a', 'null', 'null'),
(6, 'Nuovo post da Gino', 'gino', 'Nuovo post, Ready to Fall', '03 Ready to Fall.m4a', 'null', 'null'),
(7, 'Cerco chitarrista', 'gino', 'Cercasi chitarrista 4 anni di esperienza per Band Punk Rock', 'null', 'null', 'null'),
(8, 'nuovo topic', 'gino', 'vi piace di più così?', 'null', 'argomento', 'null'),
(9, 'titolo', 'gino', 'ciao', 'null', 'titti', 'null'),
(10, 'lollo', 'gino', 'casty', 'null', 'gia', 'null'),
(11, 'trillipost', 'trilli', 'trillipost', 'Propaganda.mp3', 'null', 'null'),
(12, 'trillirequest', 'trilli', 'trillirequest', 'null', 'null', 'null'),
(13, 'trillitopic', 'trilli', 'trillitopic', 'null', 'trillitopic', 'null'),
(14, 'nuovo titolo', 'gino', 'Descrizione post', 'null', 'Argomento post', 'null'),
(15, 'request titolo', 'gino', 'Descrizione request', 'null', 'null', 'null');

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

CREATE TABLE `utenti` (
  `idUtente` int(10) UNSIGNED NOT NULL,
  `username` varchar(18) NOT NULL,
  `password` varchar(18) NOT NULL,
  `email` varchar(45) NOT NULL,
  `firstname` varchar(18) NOT NULL,
  `lastname` varchar(18) DEFAULT 'null',
  `subsdate` varchar(13) NOT NULL,
  `birthdate` varchar(13) NOT NULL,
  `flag` int(2) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`idUtente`, `username`, `password`, `email`, `firstname`, `lastname`, `subsdate`, `birthdate`, `flag`) VALUES
(1, 'gino', 'gino', 'gino@gino.gino', 'pina', 'gino@prova.gino', '2021-01-16', '1995-01-12', 0),
(3, 'admin', 'admin', 'admin@admin.admin', 'admin', 'null', '2021-01-16', '1999-04-15', 1),
(4, 'palo', 'palo', 'palo@palo.palo', 'palo', 'null', '2021-01-16', '1997-01-15', 0),
(5, 'casa', 'casa', 'casa@casa.casa', 'casa', 'null', '2021-01-16', '2006-01-11', 0),
(6, 'fase', 'fase', 'fase@fase.fase', 'fase', 'null', '2021-01-16', '1998-01-15', 0),
(7, 'trilli', 'trilli', 'trilli@trilli.trilli', 'trilli', 'null', '2021-01-16', '1993-04-21', 0);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `messaggi`
--
ALTER TABLE `messaggi`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `notifica`
--
ALTER TABLE `notifica`
  ADD PRIMARY KEY (`username`);

--
-- Indici per le tabelle `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`idPost`);

--
-- Indici per le tabelle `utenti`
--
ALTER TABLE `utenti`
  ADD PRIMARY KEY (`idUtente`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `messaggi`
--
ALTER TABLE `messaggi`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `post`
--
ALTER TABLE `post`
  MODIFY `idPost` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT per la tabella `utenti`
--
ALTER TABLE `utenti`
  MODIFY `idUtente` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
