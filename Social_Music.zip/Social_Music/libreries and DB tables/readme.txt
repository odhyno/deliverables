How to start DB:

- Download Xampp - > press start on Apache and then MYSQL server

- Open PHPMyAdmin on url http://127.0.0.1/phpmyadmin/index.php

- create new db, insert name and import DB that is in this dir


